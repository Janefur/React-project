import React from "react";

function Footer() {
  return (
    <div className="footer_container">
      <p> Copyright &copy; 2025 Annika</p>
      <hr />
    </div>
  );
}

export default Footer;
